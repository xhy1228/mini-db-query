# -*- coding: utf-8 -*-
"""
Patch script: Fix change-password API route
Version: v1.2.1.07 -> v1.2.1.08
Fix: "修改失败: 请求的资源不存在" error in admin panel
"""

import os

def patch_auth_file():
    """Fix the change-password API route in auth.py"""
    
    auth_file = os.path.join(os.path.dirname(__file__), 'backend', 'api', 'auth.py')
    
    if not os.path.exists(auth_file):
        print(f"Error: {auth_file} not found")
        return False
    
    with open(auth_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Fix the route path
    old_route = '@router.post("/change-password")'
    new_route = '@router.post("/auth/change-password")'
    
    if new_route in content:
        print("Already patched!")
        return True
    
    if old_route not in content:
        print("Warning: change-password route not found in expected format")
        return False
    
    content = content.replace(old_route, new_route)
    
    with open(auth_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print("Patched successfully!")
    return True

def update_version():
    """Update version.py"""
    version_file = os.path.join(os.path.dirname(__file__), 'backend', 'version.py')
    
    with open(version_file, 'w', encoding='utf-8') as f:
        f.write('1.2.1.08\n')
    
    print("Version updated to 1.2.1.08")

if __name__ == '__main__':
    print("=" * 50)
    print("Patch: Fix change-password API route")
    print("Version: v1.2.1.07 -> v1.2.1.08")
    print("=" * 50)
    
    if patch_auth_file():
        update_version()
        print("\nPatch applied successfully!")
        print("Please restart the backend service.")
    else:
        print("\nPatch failed!")
