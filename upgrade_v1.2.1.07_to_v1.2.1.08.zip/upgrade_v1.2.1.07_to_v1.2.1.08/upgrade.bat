@echo off
chcp 65001 >nul
echo ================================================
echo   升级包 v1.2.1.07 -> v1.2.1.08
echo   修复：管理后台修改密码报错
echo ================================================
echo.

echo [1/2] 正在应用补丁...
echo.

REM Find and replace the route
powershell -Command "(Get-Content backend\api\auth.py) -replace '@router.post(\"/change-password\")', '@router.post(\"/auth/change-password\")' | Set-Content backend\api\auth.py"

if %errorlevel% neq 0 (
    echo 补丁应用失败，请手动修改
    pause
    exit /b 1
)
echo 补丁应用完成

echo.
echo [2/2] 更新版本号...
echo 1.2.1.08 > backend\version.py
echo 版本更新完成

echo.
echo ================================================
echo   升级完成！
echo   请重启后端服务使更改生效
echo ================================================
echo.
pause
