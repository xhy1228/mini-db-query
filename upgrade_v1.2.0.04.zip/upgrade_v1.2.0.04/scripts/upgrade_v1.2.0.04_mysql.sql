-- =====================================================
-- v1.2.0.04 完整数据库升级脚本 (MySQL兼容版)
-- 执行时间: 2026-03-21
-- =====================================================

-- 1. query_templates 表 - 添加缺失字段
ALTER TABLE query_templates ADD COLUMN supported_db_types JSON NULL COMMENT '支持的数据库类型';
ALTER TABLE query_templates ADD COLUMN version VARCHAR(20) DEFAULT 'v1.0.0' COMMENT '版本号';
ALTER TABLE query_templates ADD COLUMN change_log TEXT NULL COMMENT '变更日志';
ALTER TABLE query_templates ADD COLUMN category_id INT NULL COMMENT '业务大类ID';
ALTER TABLE query_templates ADD COLUMN school_id INT NULL COMMENT '学校ID(兼容旧版)';
ALTER TABLE query_templates ADD COLUMN database_id INT NULL COMMENT '数据库配置ID(兼容旧版)';

-- 2. system_configs 表 - 添加缺失字段
ALTER TABLE system_configs ADD COLUMN display_name VARCHAR(100) NULL COMMENT '显示名称';
ALTER TABLE system_configs ADD COLUMN description TEXT NULL COMMENT '描述';
ALTER TABLE system_configs ADD COLUMN category VARCHAR(50) DEFAULT 'system' COMMENT '分类: wechat/system/security';

-- 3. users 表 - 添加缺失字段
ALTER TABLE users ADD COLUMN id_card VARCHAR(255) NULL COMMENT '身份证号(加密)';
ALTER TABLE users ADD COLUMN openid VARCHAR(100) NULL COMMENT '微信openid';
ALTER TABLE users ADD COLUMN unionid VARCHAR(100) NULL COMMENT '微信unionid';
ALTER TABLE users ADD COLUMN avatar VARCHAR(500) NULL COMMENT '头像URL';
ALTER TABLE users ADD COLUMN last_login DATETIME NULL COMMENT '最后登录时间';

-- 4. query_logs 表 - 添加缺失字段
ALTER TABLE query_logs ADD COLUMN binding_id INT NULL COMMENT '绑定ID';
ALTER TABLE query_logs ADD COLUMN query_name VARCHAR(200) NULL COMMENT '查询名称';
ALTER TABLE query_logs ADD COLUMN sql_executed TEXT NULL COMMENT '执行的SQL';
ALTER TABLE query_logs ADD COLUMN error_detail JSON NULL COMMENT '错误详情';

-- 5. template_categories 表 - 添加缺失字段
ALTER TABLE template_categories ADD COLUMN is_system INT DEFAULT 0 COMMENT '是否系统预置：1是 0否';

-- 6. database_configs 表 - 添加缺失字段
ALTER TABLE database_configs ADD COLUMN driver VARCHAR(100) NULL COMMENT 'ODBC驱动';
ALTER TABLE database_configs ADD COLUMN description TEXT NULL COMMENT '描述';

-- 7. query_template_history 表 - 添加缺失字段
ALTER TABLE query_template_history ADD COLUMN name VARCHAR(100) NULL COMMENT '查询名称';
ALTER TABLE query_template_history ADD COLUMN description TEXT NULL COMMENT '描述';
ALTER TABLE query_template_history ADD COLUMN fields JSON NULL COMMENT '查询字段配置';
ALTER TABLE query_template_history ADD COLUMN changed_by INT NULL COMMENT '修改人ID';

-- 8. school_template_bindings 表 - 创建（如果不存在）
CREATE TABLE IF NOT EXISTS school_template_bindings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    school_id INT NOT NULL COMMENT '学校ID',
    template_id INT NOT NULL COMMENT '模板ID',
    database_id INT NOT NULL COMMENT '使用的数据库ID',
    enabled INT DEFAULT 1 COMMENT '是否启用：1启用 0禁用',
    custom_name VARCHAR(100) NULL COMMENT '自定义名称',
    sort_order INT DEFAULT 0 COMMENT '排序',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='学校模板绑定表';

-- 9. template_permissions 表 - 创建（如果不存在）
CREATE TABLE IF NOT EXISTS template_permissions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL COMMENT '用户ID',
    template_id INT NOT NULL COMMENT '模板ID',
    can_query INT DEFAULT 1 COMMENT '可查询',
    can_export INT DEFAULT 0 COMMENT '可导出',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '授权时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='模板权限表';

-- 10. user_schools 表 - 创建（如果不存在）
CREATE TABLE IF NOT EXISTS user_schools (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL COMMENT '用户ID',
    school_id INT NOT NULL COMMENT '学校ID',
    permissions JSON NULL COMMENT '权限列表',
    template_permissions JSON NULL COMMENT '模板权限详情',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '授权时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户学校关联表';

-- 11. query_fields 表 - 创建（如果不存在）
CREATE TABLE IF NOT EXISTS query_fields (
    id INT PRIMARY KEY AUTO_INCREMENT,
    template_id INT NOT NULL COMMENT '模板ID',
    field_key VARCHAR(50) NOT NULL COMMENT '字段标识',
    field_label VARCHAR(100) NOT NULL COMMENT '字段名称',
    field_type VARCHAR(20) DEFAULT 'text' COMMENT '字段类型',
    db_column VARCHAR(100) NULL COMMENT '数据库列名',
    operator VARCHAR(20) DEFAULT '=' COMMENT '操作符',
    default_value VARCHAR(255) NULL COMMENT '默认值',
    options JSON NULL COMMENT '选项',
    required INT DEFAULT 0 COMMENT '是否必填',
    sort_order INT DEFAULT 0 COMMENT '排序',
    placeholder VARCHAR(200) NULL COMMENT '提示文字',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='查询字段配置表';
