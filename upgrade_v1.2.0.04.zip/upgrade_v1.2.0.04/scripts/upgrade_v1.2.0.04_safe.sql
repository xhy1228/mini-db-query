-- =====================================================
-- v1.2.0.04 数据库升级脚本 (安全版)
-- 只会添加不存在的字段，遇到已存在的会跳过
-- =====================================================

SELECT '开始检查并升级数据库...' AS status;

-- =====================================================
-- 1. query_templates 表
-- =====================================================
-- supported_db_types
SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'query_templates' AND COLUMN_NAME = 'supported_db_types';
IF @cnt = 0 THEN
    ALTER TABLE query_templates ADD COLUMN supported_db_types JSON NULL COMMENT '支持的数据库类型';
    SELECT '添加 supported_db_types 成功' AS result;
ELSE
    SELECT 'supported_db_types 已存在，跳过' AS result;
END IF;

-- version
SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'query_templates' AND COLUMN_NAME = 'version';
IF @cnt = 0 THEN
    ALTER TABLE query_templates ADD COLUMN version VARCHAR(20) DEFAULT 'v1.0.0' COMMENT '版本号';
    SELECT '添加 version 成功' AS result;
ELSE
    SELECT 'version 已存在，跳过' AS result;
END IF;

-- change_log
SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'query_templates' AND COLUMN_NAME = 'change_log';
IF @cnt = 0 THEN
    ALTER TABLE query_templates ADD COLUMN change_log TEXT NULL COMMENT '变更日志';
    SELECT '添加 change_log 成功' AS result;
ELSE
    SELECT 'change_log 已存在，跳过' AS result;
END IF;

-- category_id
SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'query_templates' AND COLUMN_NAME = 'category_id';
IF @cnt = 0 THEN
    ALTER TABLE query_templates ADD COLUMN category_id INT NULL COMMENT '业务大类ID';
    SELECT '添加 category_id 成功' AS result;
ELSE
    SELECT 'category_id 已存在，跳过' AS result;
END IF;

-- =====================================================
-- 2. system_configs 表
-- =====================================================
SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'system_configs' AND COLUMN_NAME = 'display_name';
IF @cnt = 0 THEN
    ALTER TABLE system_configs ADD COLUMN display_name VARCHAR(100) NULL COMMENT '显示名称';
    SELECT '添加 display_name 成功' AS result;
ELSE
    SELECT 'display_name 已存在，跳过' AS result;
END IF;

SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'system_configs' AND COLUMN_NAME = 'description';
IF @cnt = 0 THEN
    ALTER TABLE system_configs ADD COLUMN description TEXT NULL COMMENT '描述';
    SELECT '添加 description 成功' AS result;
ELSE
    SELECT 'description 已存在，跳过' AS result;
END IF;

SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'system_configs' AND COLUMN_NAME = 'category';
IF @cnt = 0 THEN
    ALTER TABLE system_configs ADD COLUMN category VARCHAR(50) DEFAULT 'system' COMMENT '分类';
    SELECT '添加 category 成功' AS result;
ELSE
    SELECT 'category 已存在，跳过' AS result;
END IF;

-- =====================================================
-- 3. users 表
-- =====================================================
SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'users' AND COLUMN_NAME = 'id_card';
IF @cnt = 0 THEN
    ALTER TABLE users ADD COLUMN id_card VARCHAR(255) NULL COMMENT '身份证号';
    SELECT '添加 id_card 成功' AS result;
ELSE
    SELECT 'id_card 已存在，跳过' AS result;
END IF;

SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'users' AND COLUMN_NAME = 'last_login';
IF @cnt = 0 THEN
    ALTER TABLE users ADD COLUMN last_login DATETIME NULL COMMENT '最后登录时间';
    SELECT '添加 last_login 成功' AS result;
ELSE
    SELECT 'last_login 已存在，跳过' AS result;
END IF;

-- =====================================================
-- 4. query_logs 表
-- =====================================================
SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'query_logs' AND COLUMN_NAME = 'binding_id';
IF @cnt = 0 THEN
    ALTER TABLE query_logs ADD COLUMN binding_id INT NULL COMMENT '绑定ID';
    SELECT '添加 binding_id 成功' AS result;
ELSE
    SELECT 'binding_id 已存在，跳过' AS result;
END IF;

SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'query_logs' AND COLUMN_NAME = 'query_name';
IF @cnt = 0 THEN
    ALTER TABLE query_logs ADD COLUMN query_name VARCHAR(200) NULL COMMENT '查询名称';
    SELECT '添加 query_name 成功' AS result;
ELSE
    SELECT 'query_name 已存在，跳过' AS result;
END IF;

SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'query_logs' AND COLUMN_NAME = 'sql_executed';
IF @cnt = 0 THEN
    ALTER TABLE query_logs ADD COLUMN sql_executed TEXT NULL COMMENT '执行的SQL';
    SELECT '添加 sql_executed 成功' AS result;
ELSE
    SELECT 'sql_executed 已存在，跳过' AS result;
END IF;

SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'query_logs' AND COLUMN_NAME = 'error_detail';
IF @cnt = 0 THEN
    ALTER TABLE query_logs ADD COLUMN error_detail JSON NULL COMMENT '错误详情';
    SELECT '添加 error_detail 成功' AS result;
ELSE
    SELECT 'error_detail 已存在，跳过' AS result;
END IF;

-- =====================================================
-- 5. template_categories 表
-- =====================================================
SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'template_categories' AND COLUMN_NAME = 'is_system';
IF @cnt = 0 THEN
    ALTER TABLE template_categories ADD COLUMN is_system INT DEFAULT 0 COMMENT '是否系统预置';
    SELECT '添加 is_system 成功' AS result;
ELSE
    SELECT 'is_system 已存在，跳过' AS result;
END IF;

-- =====================================================
-- 6. database_configs 表
-- =====================================================
SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'database_configs' AND COLUMN_NAME = 'driver';
IF @cnt = 0 THEN
    ALTER TABLE database_configs ADD COLUMN driver VARCHAR(100) NULL COMMENT 'ODBC驱动';
    SELECT '添加 driver 成功' AS result;
ELSE
    SELECT 'driver 已存在，跳过' AS result;
END IF;

SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'database_configs' AND COLUMN_NAME = 'description';
IF @cnt = 0 THEN
    ALTER TABLE database_configs ADD COLUMN description TEXT NULL COMMENT '描述';
    SELECT '添加 description 成功' AS result;
ELSE
    SELECT 'description 已存在，跳过' AS result;
END IF;

-- =====================================================
-- 7. query_template_history 表
-- =====================================================
SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'query_template_history' AND COLUMN_NAME = 'name';
IF @cnt = 0 THEN
    ALTER TABLE query_template_history ADD COLUMN name VARCHAR(100) NULL COMMENT '查询名称';
    SELECT '添加 name 成功' AS result;
ELSE
    SELECT 'name 已存在，跳过' AS result;
END IF;

SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'query_template_history' AND COLUMN_NAME = 'description';
IF @cnt = 0 THEN
    ALTER TABLE query_template_history ADD COLUMN description TEXT NULL COMMENT '描述';
    SELECT '添加 description 成功' AS result;
ELSE
    SELECT 'description 已存在，跳过' AS result;
END IF;

SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'query_template_history' AND COLUMN_NAME = 'fields';
IF @cnt = 0 THEN
    ALTER TABLE query_template_history ADD COLUMN fields JSON NULL COMMENT '查询字段配置';
    SELECT '添加 fields 成功' AS result;
ELSE
    SELECT 'fields 已存在，跳过' AS result;
END IF;

SELECT COUNT(*) INTO @cnt FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'query_template_history' AND COLUMN_NAME = 'changed_by';
IF @cnt = 0 THEN
    ALTER TABLE query_template_history ADD COLUMN changed_by INT NULL COMMENT '修改人ID';
    SELECT '添加 changed_by 成功' AS result;
ELSE
    SELECT 'changed_by 已存在，跳过' AS result;
END IF;

-- =====================================================
-- 8. school_template_bindings 表
-- =====================================================
SELECT COUNT(*) INTO @cnt FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = 'mini_db_query' AND TABLE_NAME = 'school_template_bindings';
IF @cnt = 0 THEN
    CREATE TABLE school_template_bindings (
        id INT PRIMARY KEY AUTO_INCREMENT,
        school_id INT NOT NULL,
        template_id INT NOT NULL,
        database_id INT NOT NULL,
        enabled INT DEFAULT 1,
        custom_name VARCHAR(100) NULL,
        sort_order INT DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    SELECT '创建 school_template_bindings 表成功' AS result;
ELSE
    SELECT 'school_template_bindings 表已存在，跳过' AS result;
END IF;

SELECT '✅ 数据库升级完成!' AS status;
