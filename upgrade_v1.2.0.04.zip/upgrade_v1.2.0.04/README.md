# v1.2.0.04 升级包（完整版）

## ⚠️ 重要：必须先执行数据库升级！

本次升级涉及大量数据库字段变更，**必须先执行SQL脚本**，否则会报错。

## 更新内容

### v1.2.0.03 功能（整合）
1. **小程序历史记录优化**
   - 添加删除单条记录功能
   - 优化清空历史提示文案

### v1.2.0.04 修复
2. **业务大类加载问题** - 页面初始化时自动加载业务大类数据
3. **数据库字段修复** - 添加多个表缺失的字段

## 文件清单

```
upgrade_v1.2.0.04/
├── README.md
├── backend/
│   ├── admin/index.html
│   └── version.py
├── miniapp/
│   └── pages/
│       └── history/
│           ├── history.js
│           ├── history.wxml
│           └── history.wxss
└── scripts/
    ├── upgrade_v1.2.0.04.sql      # 基础修复
    └── upgrade_v1.2.0.04_full.sql # ⭐ 完整修复（推荐）
```

## 升级步骤

### 1. ⭐ 执行完整数据库升级脚本（必须！）

```sql
-- 登录MySQL
mysql -u root -p mini_db_query

-- 执行完整升级脚本
source upgrade_v1.2.0.04_full.sql

-- 或直接在MySQL客户端执行
```

**脚本会自动添加以下缺失字段：**
- `query_templates`: supported_db_types, version, change_log, category_id 等
- `system_configs`: display_name, description, category
- `users`: id_card, openid, unionid, avatar, last_login
- `query_logs`: binding_id, query_name, sql_executed, error_detail
- `template_categories`: is_system
- `database_configs`: driver, description
- `query_template_history`: name, description, fields, changed_by

### 2. 替换后端文件

- 覆盖 `backend/admin/index.html`
- 覆盖 `backend/version.py`

### 3. 替换小程序文件（可选）

- 覆盖 `miniapp/pages/history/` 目录

### 4. 重启后端服务

```cmd
taskkill /F /IM python.exe
cd backend
python main.py
```

### 5. 验证升级成功

刷新管理平台，检查：
- 业务大类是否正常显示
- 查询模板是否正常加载

## 版本号

v1.2.0.04
