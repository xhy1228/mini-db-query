# v1.2.0.04 升级包（完整版）

## 更新内容

### v1.2.0.03 功能（整合）
1. **小程序历史记录优化**
   - 添加删除单条记录功能
   - 优化清空历史提示文案
   - 修复删除 API 调用方式

### v1.2.0.04 修复
2. **业务大类加载问题** - 页面初始化时自动加载业务大类数据
3. **数据库修复** - system_configs 表添加缺失字段

## 文件清单

```
upgrade_v1.2.0.04/
├── README.md
├── backend/
│   ├── admin/index.html
│   └── version.py
├── miniapp/
│   └── pages/
│       └── history/
│           ├── history.js
│           ├── history.wxml
│           └── history.wxss
└── scripts/
    └── upgrade_v1.2.0.04.sql
```

## 升级步骤

### 1. 执行数据库升级脚本

```sql
-- 登录MySQL后执行
ALTER TABLE system_configs ADD COLUMN display_name VARCHAR(100) NULL COMMENT '显示名称';
ALTER TABLE system_configs ADD COLUMN description TEXT NULL COMMENT '描述';
ALTER TABLE system_configs ADD COLUMN category VARCHAR(50) DEFAULT 'system' COMMENT '分类: wechat/system/security';
```

### 2. 替换后端文件

- 覆盖 `backend/admin/index.html`
- 覆盖 `backend/version.py`

### 3. 替换小程序文件

- 覆盖 `miniapp/pages/history/history.js`
- 覆盖 `miniapp/pages/history/history.wxml`
- 覆盖 `miniapp/pages/history/history.wxss`

### 4. 重新编译小程序

### 5. 重启后端服务

```cmd
taskkill /F /IM python.exe
cd backend
python main.py
```

## 版本号

v1.2.0.04
