# ============================================
# Mini DB Query - PowerShell Installation Script
# Version: v1.0.0
# Usage: powershell -ExecutionPolicy Bypass -File install.ps1
# ============================================

param(
    [string]$MysqlHost = "localhost",
    [int]$MysqlPort = 3306,
    [string]$MysqlUser = "root",
    [string]$MysqlPassword = "",
    [string]$Database = "mini_db_query",
    [switch]$SkipMysql,
    [switch]$Quiet
)

# Configuration
$ErrorActionPreference = "Stop"
$ProjectDir = Split-Path -Parent $PSScriptRoot
$BackendDir = Join-Path $ProjectDir "backend"
$DatabaseDir = Join-Path $ProjectDir "database"

# Log functions
function Write-Info { Write-Host "[OK] $args" -ForegroundColor Green }
function Write-Warn { Write-Host "[WARN] $args" -ForegroundColor Yellow }
function Write-Err { Write-Host "[ERROR] $args" -ForegroundColor Red }
function Write-Step { 
    Write-Host "`n========================================" -ForegroundColor Cyan
    Write-Host $args -ForegroundColor Cyan
    Write-Host "========================================`n" -ForegroundColor Cyan
}

# Check admin
function Test-Admin {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Install Python
function Install-Python {
    Write-Step "Step 1: Checking Python"
    
    $python = Get-Command python -ErrorAction SilentlyContinue
    if ($python) {
        $version = & python --version 2>&1
        Write-Info "$version found"
        return $true
    }
    
    Write-Warn "Python not found, installing..."
    
    $pythonUrl = "https://www.python.org/ftp/python/3.12.0/python-3.12.0-amd64.exe"
    $installerPath = Join-Path $env:TEMP "python-installer.exe"
    
    try {
        Write-Info "Downloading Python 3.12..."
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $pythonUrl -OutFile $installerPath -UseBasicParsing
        
        Write-Info "Installing Python..."
        Start-Process -FilePath $installerPath -ArgumentList @(
            "/quiet",
            "InstallAllUsers=0",
            "PrependPath=1",
            "Include_test=0",
            "Include_pip=1"
        ) -Wait
        
        # Refresh PATH
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "User") + ";" + 
                    [System.Environment]::GetEnvironmentVariable("Path", "Machine")
        
        Write-Info "Python installed"
        return $true
    }
    catch {
        Write-Err "Python installation failed: $_"
        Write-Warn "Please install manually: https://www.python.org/downloads/"
        return $false
    }
}

# Create virtual environment
function New-VirtualEnv {
    Write-Step "Step 2: Creating Virtual Environment"
    
    Push-Location $BackendDir
    
    $venvPath = Join-Path $BackendDir "venv"
    
    if (Test-Path $venvPath) {
        Write-Warn "Virtual environment already exists"
    }
    else {
        Write-Info "Creating virtual environment..."
        & python -m venv venv
        Write-Info "Virtual environment created"
    }
    
    # Activate
    & "$venvPath\Scripts\Activate.ps1"
    
    # Upgrade pip
    & python -m pip install --upgrade pip --quiet
    
    Pop-Location
}

# Install dependencies
function Install-Dependencies {
    Write-Step "Step 3: Installing Dependencies"
    
    Push-Location $BackendDir
    
    $requirementsPath = Join-Path $BackendDir "requirements.txt"
    
    if (Test-Path $requirementsPath) {
        Write-Info "Installing packages..."
        & pip install -r requirements.txt --quiet
        Write-Info "Core packages installed"
    }
    else {
        throw "requirements.txt not found"
    }
    
    # Install database drivers
    & pip install pymysql cryptography oracledb pyodbc --quiet 2>$null
    Write-Info "Database drivers installed"
    
    Pop-Location
}

# Configure MySQL
function Initialize-MySQL {
    Write-Step "Step 4: Configuring MySQL"
    
    # Check MySQL service
    $mysqlService = Get-Service -Name "MySQL*" -ErrorAction SilentlyContinue | 
                    Where-Object { $_.Status -eq "Running" } | 
                    Select-Object -First 1
    
    if (-not $mysqlService) {
        Write-Warn "No running MySQL service detected"
        Write-Warn "Please ensure MySQL 8.0.2+ is installed and running"
        
        if (-not $SkipMysql) {
            $continue = Read-Host "Continue anyway? (Y/N)"
            if ($continue -ne "Y") {
                Write-Warn "Installation paused"
                exit 0
            }
        }
    }
    else {
        Write-Info "MySQL service detected: $($mysqlService.Name)"
    }
    
    # Get MySQL password
    if (-not $MysqlPassword) {
        $MysqlPassword = Read-Host "Enter MySQL root password"
    }
    
    # Create database init SQL
    $initSql = @"
CREATE DATABASE IF NOT EXISTS `$Database` DEFAULT CHARACTER SET utf8mb4 DEFAULT COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'mini_query'@'localhost' IDENTIFIED BY 'MiniQuery@2026';
GRANT ALL PRIVILEGES ON `$Database`.* TO 'mini_query'@'localhost';
FLUSH PRIVILEGES;
"@
    
    $initSqlPath = Join-Path $env:TEMP "init_db.sql"
    $initSql | Out-File -FilePath $initSqlPath -Encoding UTF8
    
    # Execute SQL
    $mysqlExe = Get-Command mysql -ErrorAction SilentlyContinue
    if ($mysqlExe) {
        Write-Info "Creating database..."
        & mysql -h$MysqlHost -P$MysqlPort -u$MysqlUser -p$MysqlPassword < $initSqlPath 2>$null
        Write-Info "Database created"
        
        # Create tables
        $schemaPath = Join-Path $DatabaseDir "mysql_schema.sql"
        if (Test-Path $schemaPath) {
            Write-Info "Creating tables..."
            & mysql -h$MysqlHost -P$MysqlPort -u$MysqlUser -p$MysqlPassword $Database < $schemaPath 2>$null
            Write-Info "Tables created"
        }
    }
    else {
        Write-Warn "mysql command not found, please run SQL manually"
        Write-Host $initSql
    }
}

# Create config file
function New-Config {
    Write-Step "Step 5: Creating Configuration"
    
    # Generate JWT secret
    $jwtSecret = -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 64 | ForEach-Object { [char]$_ })
    
    $envContent = @"
# Mini DB Query Configuration
# Generated: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")

# Database
DATABASE_URL=mysql+pymysql://root:password@$MysqlHost`:$MysqlPort/$Database?charset=utf8mb4

# WeChat Mini Program
WECHAT_APPID=your_appid_here
WECHAT_SECRET=your_secret_here

# JWT
JWT_SECRET_KEY=$jwtSecret
JWT_EXPIRE_MINUTES=10080

# Server
HOST=0.0.0.0
PORT=26316
DEBUG=False
"@
    
    $envPath = Join-Path $BackendDir ".env"
    $envContent | Out-File -FilePath $envPath -Encoding UTF8
    
    Write-Info "Config created: $envPath"
}

# Main
function Main {
    Write-Host "`n============================================" -ForegroundColor Green
    Write-Host "   Mini DB Query - Installation Wizard" -ForegroundColor Green
    Write-Host "============================================`n" -ForegroundColor Green
    
    try {
        Install-Python
        New-VirtualEnv
        Install-Dependencies
        
        if (-not $SkipMysql) {
            Initialize-MySQL
        }
        
        New-Config
        
        # Done
        Write-Host "`n============================================" -ForegroundColor Green
        Write-Host "   Installation Complete!" -ForegroundColor Green
        Write-Host "============================================`n" -ForegroundColor Green
        
        Write-Host "Default Admin Account:"
        Write-Host "  Username: admin" -ForegroundColor Yellow
        Write-Host "  Password: 123456" -ForegroundColor Yellow
        
        Write-Host "`nNext Steps:"
        Write-Host "  1. Edit backend\.env with your settings" -ForegroundColor Cyan
        Write-Host "  2. Run scripts\start.bat to start server" -ForegroundColor Cyan
        Write-Host "  3. Open http://localhost:8000/docs" -ForegroundColor Cyan
        
        # Open config
        if (-not $Quiet) {
            $openConfig = Read-Host "Open config file now? (Y/N)"
            if ($openConfig -eq "Y") {
                notepad (Join-Path $BackendDir ".env")
            }
        }
    }
    catch {
        Write-Err "Installation failed: $_"
        Write-Err $_.ScriptStackTrace
        exit 1
    }
}

# Run
Main
