@echo off
REM ============================================
REM Mini DB Query - Stop Server
REM ============================================

echo Stopping Mini DB Query server...

REM Kill Python processes running main.py
taskkill /f /fi "WINDOWTITLE eq Mini DB Query*" 2>nul
taskkill /f /im python.exe /fi "MEMUSAGE gt 10000" 2>nul

echo Server stopped.
timeout /t 2 >nul
