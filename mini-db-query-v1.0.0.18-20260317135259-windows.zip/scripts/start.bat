@echo off
REM Mini DB Query - Quick Start
REM Use this to start the server after installation

cd /d "%~dp0"
cd backend
call run_service.bat
