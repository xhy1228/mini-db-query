# Mini DB Query v1.2.0.02 升级包

## 升级说明

本次升级为 v1.2.0 架构重构，实现"一校多库"功能，支持：
- 一个学校配置多个数据库（MySQL + Oracle）
- 模板复用，多个学校共用同一个查询模板
- 功能绑定，学校选择模板+数据库组合

---

## 📦 文件清单

### 后端文件
| 文件 | 说明 |
|------|------|
| `backend/version.py` | 版本号 v1.2.0.02 |
| `backend/api/query.py` | 新增 `/user/query/binding` 查询接口 |
| `backend/admin/index.html` | 新增功能绑定管理界面 |

### 小程序文件
| 文件 | 说明 |
|------|------|
| `miniapp/pages/index/index.js` | 使用新 API 加载功能列表 |
| `miniapp/pages/query/query.js` | 使用 `/user/query/binding` 查询 |
| `miniapp/pages/query/query.wxml` | 适配新数据结构 |

### 数据库脚本
| 文件 | 说明 |
|------|------|
| `scripts/upgrade_v1.2.0.00.sql` | 创建 school_template_bindings 表 |

---

## 🚀 升级步骤

### 1. 备份数据
升级前务必备份数据库！

### 2. 执行数据库升级
```bash
mysql -u root -p < scripts/upgrade_v1.2.0.00.sql
```

### 3. 替换后端文件
将以下文件覆盖到服务器对应位置：
```
backend/version.py → backend/version.py
backend/api/query.py → backend/api/query.py
backend/admin/index.html → backend/admin/index.html
```

### 4. 替换小程序文件
将以下文件覆盖到小程序项目中：
```
miniapp/pages/index/index.js → miniapp/pages/index/index.js
miniapp/pages/query/query.js → miniapp/pages/query/query.js
miniapp/pages/query/query.wxml → miniapp/pages/query/query.wxml
```

### 5. 重启后端服务
```bash
cd backend
python main.py
```

### 6. 提交小程序审核
使用微信开发者工具上传新版本，提交审核。

---

## 📋 配置指南

### 首次配置流程

1. **配置数据库连接**
   - 管理后台 → 数据库配置
   - 为学校添加 MySQL 和 Oracle 连接

2. **创建查询模板**
   - 管理后台 → 查询模板
   - 创建通用的查询模板

3. **绑定功能**
   - 管理后台 → 学校管理
   - 点击学校后的"🔗 功能配置"
   - 添加功能绑定（选择模板 + 选择数据库）

---

## ⚠️ 注意事项

1. **数据库必须先升级**，否则后端无法启动
2. **不要遗漏小程序文件**，否则功能列表无法正常显示
3. **配置绑定后才能使用**，小程序只能看到已绑定的功能

---

## 🐛 常见问题

**Q: 升级后小程序看不到功能？**
A: 需要在管理后台配置"功能绑定"，小程序才能显示。

**Q: 数据库连接失败？**
A: 检查数据库配置，确保 MySQL/Oracle 连接信息正确。

---

*升级包版本: v1.2.0.02*
*生成时间: 2026-03-21*
