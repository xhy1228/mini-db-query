// pages/query/query.js
// 查询页面 - v1.2.0 使用 binding API

const app = getApp()
const { get, post } = require('../../utils/request')

Page({
  data: {
    // 当前学校
    selectedSchool: null,
    
    // 功能列表（按分类）
    categories: [],
    selectedCategory: null,
    
    // 选中的功能（binding）
    selectedFunction: null,
    
    // 查询条件
    conditions: [],
    startTime: '',
    endTime: '',
    
    // 快捷时间
    quickTimeOptions: ['今天', '近7天', '近30天', '本月'],
    selectedQuickTime: '',
    
    // 查询结果
    loading: false,
    result: [],
    resultColumns: [],
    queried: false,
    queryTime: 0,
    errorInfo: null,
    
    // 导出相关
    exporting: false,
    showExportModal: false,
    
    // 详情弹窗
    showDetailModal: false,
    detailData: [],
    
    // 排序功能
    sortColumn: '',
    sortOrder: '',
  },

  onLoad(options) {
    // 检查登录
    if (!app.isLoggedIn()) {
      wx.redirectTo({ url: '/pages/login/login' })
      return
    }
    
    // 获取参数
    if (options.school_id) {
      this.setData({
        selectedSchool: { id: parseInt(options.school_id), name: decodeURIComponent(options.school_name || '') }
      })
    }
    
    // 如果没有学校，从全局获取
    if (!this.data.selectedSchool && app.globalData.selectedSchool) {
      this.setData({ selectedSchool: app.globalData.selectedSchool })
    }
    
    // 加载功能列表
    this.loadFunctions()
  },

  onShow() {
    // 从全局获取选中的学校
    if (app.globalData.selectedSchool && !this.data.selectedSchool) {
      this.setData({ selectedSchool: app.globalData.selectedSchool })
      this.loadFunctions()
    }
  },

  // 加载学校可用功能（v1.2.0 新API）
  async loadFunctions() {
    const school = this.data.selectedSchool
    if (!school) {
      wx.switchTab({ url: '/pages/index/index' })
      return
    }
    
    try {
      // 使用新的 API 获取学校功能
      const res = await get(`/schools/${school.id}/functions`)
      
      if (res.code === 200 && res.data) {
        this.setData({ 
          categories: res.data.categories || []
        })
      } else {
        // 如果新 API 失败，回退到旧 API
        await this.loadCategoriesFallback()
      }
    } catch (error) {
      console.error('加载功能列表失败:', error)
      // 回退到旧 API
      await this.loadCategoriesFallback()
    }
  },

  // 回退到旧的分类 API
  async loadCategoriesFallback() {
    const school = this.data.selectedSchool
    if (!school) return
    
    try {
      const res = await get('/user/categories', { school_id: school.id })
      if (res.code === 200) {
        this.setData({ categories: res.data || [] })
      }
    } catch (error) {
      console.error('加载业务大类失败:', error)
      this.setData({
        categories: this.getMockCategories()
      })
    }
  },

  // 获取模拟分类数据
  getMockCategories() {
    return [
      { 
        category: 'student', 
        category_name: '学生业务', 
        category_icon: '🎓',
        functions: []
      }
    ]
  },

  // 选择业务大类
  onCategoryTap(e) {
    const category = e.currentTarget.dataset.category
    this.setData({ selectedCategory: category })
  },

  // 选择功能
  onFunctionTap(e) {
    const func = e.currentTarget.dataset.func
    
    // 初始化查询条件
    const conditions = (func.fields || []).map(field => ({
      field: field.column,
      operator: field.operator || '=',
      value: '',
      label: field.label,
      type: field.type,
      options: field.options
    }))
    
    this.setData({
      selectedFunction: func,
      conditions: conditions,
      startTime: '',
      endTime: '',
      selectedQuickTime: ''
    })
  },

  // 输入查询条件
  onConditionInput(e) {
    const index = e.currentTarget.dataset.index
    const value = e.detail.value
    
    const conditions = this.data.conditions
    conditions[index].value = value
    
    this.setData({ conditions })
  },

  // 选择器条件变化
  onConditionPickerChange(e) {
    const index = e.currentTarget.dataset.index
    const value = e.detail.value
    
    const conditions = this.data.conditions
    conditions[index].value = value
    
    this.setData({ conditions })
  },

  // 选择时间
  onStartTimeChange(e) {
    this.setData({ startTime: e.detail.value, selectedQuickTime: '' })
  },

  onEndTimeChange(e) {
    this.setData({ endTime: e.detail.value, selectedQuickTime: '' })
  },

  // 选择快捷时间
  selectQuickTime(e) {
    const index = e.currentTarget.dataset.index
    const option = this.data.quickTimeOptions[index]
    const now = new Date()
    let startTime = ''
    let endTime = now.toISOString().split('T')[0]
    
    switch(option) {
      case '今天':
        startTime = endTime
        break
      case '近7天':
        const d7 = new Date(now - 7 * 24 * 60 * 60 * 1000)
        startTime = d7.toISOString().split('T')[0]
        break
      case '近30天':
        const d30 = new Date(now - 30 * 24 * 60 * 60 * 1000)
        startTime = d30.toISOString().split('T')[0]
        break
      case '本月':
        const firstDay = new Date(now.getFullYear(), now.getMonth(), 1)
        startTime = firstDay.toISOString().split('T')[0]
        break
    }
    
    this.setData({
      selectedQuickTime: option,
      startTime: startTime,
      endTime: endTime
    })
  },

  // 显示导出选项
  showExportOptions() {
    this.setData({ showExportModal: true })
  },

  hideExportModal() {
    this.setData({ showExportModal: false })
  },

  stopPropagation() {},

  // 复制到剪贴板
  copyToClipboard() {
    this.hideExportModal()
    
    if (!this.data.result || this.data.result.length === 0) {
      wx.showToast({ title: '无数据可复制', icon: 'none' })
      return
    }
    
    try {
      const columns = this.data.resultColumns
      const rows = this.data.result
      
      let text = columns.join('\t') + '\n'
      rows.forEach(row => {
        const values = columns.map(col => {
          const val = row[col]
          return val !== null && val !== undefined ? String(val) : '-'
        })
        text += values.join('\t') + '\n'
      })
      
      wx.setClipboardData({
        data: text,
        success: () => {
          wx.showToast({ title: '已复制到剪贴板', icon: 'success' })
        }
      })
    } catch (error) {
      wx.showToast({ title: '复制失败', icon: 'none' })
    }
  },

  // 显示行详情
  showRowDetail(e) {
    const row = e.currentTarget.dataset.row
    if (!row) return
    
    const detailData = this.data.resultColumns.map(col => ({
      label: col,
      value: row[col]
    }))
    
    this.setData({
      showDetailModal: true,
      detailData: detailData
    })
  },

  hideDetailModal() {
    this.setData({ showDetailModal: false, detailData: [] })
  },
  
  copyDetailRow() {
    const { detailData } = this.data
    if (!detailData || detailData.length === 0) return
    
    const text = detailData.map(item => `${item.label}: ${item.value != null ? item.value : '-'}`).join('\n')
    
    wx.setClipboardData({
      data: text,
      success: () => {
        wx.showToast({ title: '已复制', icon: 'success' })
      }
    })
  },
  
  copyDetailItem(e) {
    const index = e.currentTarget.dataset.index
    const item = this.data.detailData[index]
    if (!item) return
    
    wx.setClipboardData({
      data: String(item.value != null ? item.value : '-'),
      success: () => {
        wx.showToast({ title: '已复制', icon: 'success', duration: 1000 })
      }
    })
  },

  // 执行查询（v1.2.0 使用 binding_id）
  async doQuery() {
    const { selectedFunction, conditions, startTime, endTime } = this.data
    
    if (!selectedFunction) {
      wx.showToast({ title: '请先选择查询功能', icon: 'none' })
      return
    }
    
    // 验证查询条件
    const hasCondition = conditions.some(c => c.value.trim())
    if (!hasCondition) {
      wx.showToast({ title: '请至少输入一个查询条件', icon: 'none' })
      return
    }
    
    this.setData({ 
      loading: true, 
      queried: false,
      errorInfo: null 
    })
    
    try {
      // 使用新的 binding_id 查询 API
      const res = await post('/user/query/binding', {
        binding_id: selectedFunction.binding_id,
        conditions: conditions.filter(c => c.value.trim()),
        start_time: startTime ? `${startTime} 00:00:00` : null,
        end_time: endTime ? `${endTime} 23:59:59` : null,
        limit: 500
      })
      
      if (res.code === 200) {
        const result = res.data.rows || []
        const columns = result.length > 0 ? Object.keys(result[0]) : []
        
        this.setData({
          result: result,
          resultColumns: columns,
          queried: true,
          queryTime: res.data.query_time || 0,
          errorInfo: null
        })
        
        wx.showToast({
          title: `查询成功，共${result.length}条`,
          icon: 'success'
        })
      } else {
        const errorInfo = res.data?.error || {
          error_message: res.message || '查询失败',
          suggestion: '请重试或联系管理员'
        }
        
        this.setData({
          result: [],
          resultColumns: [],
          queried: true,
          errorInfo: errorInfo
        })
        
        wx.showToast({
          title: res.message || '查询失败',
          icon: 'none'
        })
      }
    } catch (error) {
      console.error('查询失败:', error)
      
      const errorInfo = {
        error_message: error.message || '网络错误',
        suggestion: '请检查网络后重试'
      }
      
      this.setData({
        result: [],
        resultColumns: [],
        queried: true,
        errorInfo: errorInfo
      })
      
      wx.showToast({
        title: '查询失败，请重试',
        icon: 'none'
      })
    } finally {
      this.setData({ loading: false })
    }
  },

  // 返回重新选择
  goBack() {
    this.setData({
      selectedFunction: null,
      selectedCategory: null,
      result: [],
      resultColumns: [],
      queried: false,
      queryTime: 0,
      errorInfo: null,
      sortColumn: '',
      sortOrder: ''
    })
  },
  
  // 点击表头排序
  onHeaderTap(e) {
    const column = e.currentTarget.dataset.column
    const { sortColumn, sortOrder, result } = this.data
    
    if (!result || result.length === 0) return
    
    let newOrder = 'asc'
    if (sortColumn === column) {
      newOrder = sortOrder === 'asc' ? 'desc' : ''
    }
    
    if (!newOrder) {
      this.setData({ sortColumn: '', sortOrder: '' })
      return
    }
    
    const sortedResult = [...result].sort((a, b) => {
      let valA = a[column]
      let valB = b[column]
      
      if (valA == null) valA = ''
      if (valB == null) valB = ''
      
      const numA = parseFloat(valA)
      const numB = parseFloat(valB)
      if (!isNaN(numA) && !isNaN(numB)) {
        return newOrder === 'asc' ? numA - numB : numB - numA
      }
      
      const strA = String(valA).toLowerCase()
      const strB = String(valB).toLowerCase()
      if (newOrder === 'asc') {
        return strA.localeCompare(strB, 'zh-CN')
      } else {
        return strB.localeCompare(strA, 'zh-CN')
      }
    })
    
    this.setData({
      result: sortedResult,
      sortColumn: column,
      sortOrder: newOrder
    })
  },
  
  // 长按复制单元格
  onCellLongPress(e) {
    const value = e.currentTarget.dataset.value
    if (value == null) return
    
    wx.setClipboardData({
      data: String(value),
      success: () => {
        wx.showToast({ title: '已复制', icon: 'success', duration: 1000 })
      }
    })
  },
  
  copyRow(e) {
    const row = e.currentTarget.dataset.row
    if (!row) return
    
    const text = this.data.resultColumns.map(col => {
      const val = row[col]
      return `${col}: ${val != null ? val : '-'}`
    }).join('\n')
    
    wx.setClipboardData({
      data: text,
      success: () => {
        wx.showToast({ title: '已复制整行', icon: 'success' })
      }
    })
  }
})
